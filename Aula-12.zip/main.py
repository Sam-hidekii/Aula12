__author__ = 'Samuel Assis'
#============================================
#Praticando com Biblioteca 
print('~~~Fatorial~~~\n')
import math
print( math.factorial(5))
print('=====================================================\n')
#============================================
#Praticando com Dicionários
print('~~~Média~~~\n')
classe = {'Anna': 4.5,
         'Beatriz': 6.5,
         'Geraldo': 1.00,
         'José': 10.00,
         'Maria': 9.5}
notas = classe.values()
media = sum(notas)/5
print("A média da classe é: ",media)
print('=====================================================\n')
#============================================
print('~~~Preços Lanchonete~~~\n')
dic = {'salgado': 3.50,
      'lanche': 6.50,
      'suco': 3.00,
      'refrigerante': 3.50,
      'doce': 1.00}
print(dic)

print('=====================================================\n')
#============================================
print('~~~Preços Mercado~~~\n')
D = {"arroz": 17.3,"feijão": 12.5,"carne": 23.9,"alface": 3.4}
print(D)
D["carne"] = 25.0
D["tomate"] = 8.80
print(D)

print('=====================================================\n')
#============================================
#Praticando com Tuplas
print('~~~Valores~~~\n')
T = (10, 20, 30, 40, 50)
a,b,c,d,e = T
print("a =",a,"b =",b)
print("c =",c,"d =",d,'e =',e)
print("\nd + e =",d+e)


print('=====================================================\n')
#============================================
#Praticando com Listas

L = [5, 7, 2, 9, 4, 1, 3]

print('~~~Listinha~~~')
print('\nLista = ',L)
print('O tamanho da lista é: ',len(L))
print('O maior elemento da Lista é: ',max(L))
print('O menor elemento da Lista é: ',min(L))
print('A soma dos elementos da Lista é: ',sum(L))

L.sort()

print('Lista em ordem crescente: ',L)

L.reverse()

print('Lista em ordem decrescente: ',L)

print('=====================================================\n')
#============================================
print('~~~Teste Abacate 3~~~\n')
L = [3,'abacate', 9.7, [5, 6, 3], "Python", (3, 'j')]

print(L[1:4])
print(L[2:])
print(L[:4])

print('=====================================================\n')
#============================================
print('~~~Teste Abacate 2~~~\n')
L = [3,'abacate', 9.7, [5, 6, 3], "Python", (3, 'j')]

print(L[5])
print(L[3])
print(L[3][1])

L[3] = 'morango'

print([L])

print('=====================================================\n')
#============================================
print('~~~Teste Abacate 1~~~\n')
L = [3,'abacate', 9.7, [5, 6, 3], "Python", (3, 'j')]
print(L[5])
print(L[3])
print(L[3][1])
#============================================

